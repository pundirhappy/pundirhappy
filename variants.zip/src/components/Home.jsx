import React from 'react';
import {  useNavigate } from 'react-router-dom';
import "./Navbar.css";
import Product from './Product';

function Home() {

    const navigate = useNavigate()
  return (
    <>
    <div className="hero">
    <div class="card bg-dark text-white">
  <img src="/pics/homepic.jpg" class='card-img' alt="background"
//    height="880"
   />
  <div class="card-img-overlay d-flex flex-column justify-content-center">
       <div className="container">
    <h5 class="ad"> Click on Product Button to Check Products </h5>

    <p class="card-text lead fs-2">
     <button onClick={()=>navigate("/products")} className='btn btn-warning btn-lg'>  Products  </button> 
         </p>
    </div>
  </div>
</div>
<Product/>
</div>
</>
  )
};

export default Home;