const list =[
    {
        id : "1",
        name: "Purple",
        price: "499",
        image: "./pics/thirtv3.jpeg",
        amount: 1,
    },
    {
        id : "2",
        name: "Grey",
        price: "299",
        image: "./pics/tshirtv2.jpeg",
        amount: 1,

    },
    {
        id : "3",
        name: "Red",
        price: "899",
        image: "./pics/red.jpeg",
        amount: 1,
    },
];

 export const shirtlist =[
    {
        id : "100",
        name: "Yellow",
        price: "499",
        image: "./pics/yellowshirt.jpg",
        amount: 1,
    },
    {
        id : "99",
        name: "Printed",
        price: "299",
        image: "./pics/printedshirt.jpeg",
        amount: 1,

    },
    {
        id : "98",
        name: "Sky Blue",
        price: "899",
        image: "./pics/shirt1.webp",
        amount: 1,
    },
];

export const boatlist =[
    {
        id : "90",
        name: "Grey",
        price: "1499",
        image: "./pics/boatgrey.jpeg",
        amount: 1,
    },
    {
        id : "91",
        name: "Red",
        price: "1299",
        image: "./pics/boatred.jpeg",
        amount: 1,

    },
    {
        id : "92",
        name: "Black",
        price: "1899",
        image: "./pics/boatbuds.jpeg",
        amount: 1,
    },
    {
        id : "93",
        name: "Yellow",
        price: "1199",
        image: "./pics/boatyellow.webp",
        amount: 1,
    },
];

export const shoelist =[
    {
        id : "11",
        name: "White",
        price: "2490",
        image: "./pics/adidas shoes.webp",
        amount: 1,
    },
    {
        id : "12",
        name: "Black",
        price: "2290",
        image: "./pics/blackshoe.webp",
        amount: 1,

    },
    {
        id : "13",
        name: "NEON ",
        price: "2890",
        image: "./pics/neonshoe.jpeg",
        amount: 1,
    },
    {
        id : "14",
        name: "PINK",
        price: "1190",
        image: "./pics/pinkshoe.jpg",
        amount: 1,
    },
    {
        id : "15",
        name: "Black & white",
        price: "2890",
        image: "./pics/whiteshoe.webp",
        amount: 1,
    },
    {
        id : "16",
        name: "Whites",
        price: "3190",
        image: "./pics/whiteshoes.webp",
        amount: 1,
    },
];

export default list  ;