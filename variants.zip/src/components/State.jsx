import React, { useState } from 'react';


const State = () => {

 const [value , setValue] = useState(0)
  
 const add = () => {
    if (value < 10) {
    setValue (value +1);
 }
};


const sub = () => {
    if (value > 0) {
    setValue (value -1);
    }
};

  return (
 <> 
 <center> 
    <div>

 <h1> {value} </h1>
 <br/>
        <button className='btn btn-warning btn-lg' onClick={add}> Add  </button> &nbsp;&nbsp;&nbsp;
        <button className='btn btn-danger btn-lg' onClick={sub}> sub  </button>

        </div>
        </center>
        </>
  )
};

export default State;