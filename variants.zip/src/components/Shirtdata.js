const shirtlist =[
    {
        id : "1",
        name: "Red",
        price: "499",
        shirtimage: "./pics/red.jpeg",
        amount: "1",
    },
    {
        id : "2",
        name: "Sky Blue",
        price: "299",
        shirtimage: "./pics/skyblueshirt.jpg",
        amount: "1",

    },
    {
        id : "3",
        name: "Yellow",
        price: "899",
        shirtimage: "./pics/yellow.jpg",
        amount: "1",
    },
];

export default shirtlist ;